import {
  require_react
} from "./chunk-TWJRYSII.js";
import "./chunk-DC5AMYBS.js";
export default require_react();
//# sourceMappingURL=react.js.map
