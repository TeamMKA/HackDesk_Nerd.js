import {
  require_leaflet_src
} from "./chunk-KVREVINV.js";
import "./chunk-DC5AMYBS.js";
export default require_leaflet_src();
//# sourceMappingURL=leaflet.js.map
